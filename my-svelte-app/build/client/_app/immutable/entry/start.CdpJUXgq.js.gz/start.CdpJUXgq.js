import{a as t}from"../chunks/entry._7qpGTCu.js";export{t as start};
