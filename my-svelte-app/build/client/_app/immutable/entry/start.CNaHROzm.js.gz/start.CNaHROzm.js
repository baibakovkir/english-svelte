import{a as t}from"../chunks/entry.C0Yxa_x8.js";export{t as start};
