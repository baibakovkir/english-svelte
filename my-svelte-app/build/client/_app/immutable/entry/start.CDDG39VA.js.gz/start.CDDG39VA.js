import{a as t}from"../chunks/entry.BaMBYfQa.js";export{t as start};
