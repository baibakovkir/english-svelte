import{a as t}from"../chunks/entry.CxMBUgBu.js";export{t as start};
