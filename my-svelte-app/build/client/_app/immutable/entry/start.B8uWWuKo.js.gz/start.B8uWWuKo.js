import{a as t}from"../chunks/entry.DyJqzqvL.js";export{t as start};
