import{a as t}from"../chunks/entry.NBK3RhFf.js";export{t as start};
