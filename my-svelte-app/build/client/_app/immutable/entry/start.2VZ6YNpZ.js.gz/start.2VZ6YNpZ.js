import{a as t}from"../chunks/entry.CBNhqCKv.js";export{t as start};
