import{a as t}from"../chunks/entry.CG9aOgaE.js";export{t as start};
