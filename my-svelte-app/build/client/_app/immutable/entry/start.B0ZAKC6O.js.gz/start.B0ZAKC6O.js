import{a as t}from"../chunks/entry.BizMaWXL.js";export{t as start};
