import{a as t}from"../chunks/entry.BaVYRdWZ.js";export{t as start};
