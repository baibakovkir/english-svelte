import{a as t}from"../chunks/entry.2xqjaWZi.js";export{t as start};
