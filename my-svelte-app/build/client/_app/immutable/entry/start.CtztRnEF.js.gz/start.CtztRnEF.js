import{a as t}from"../chunks/entry.BeFprjMY.js";export{t as start};
