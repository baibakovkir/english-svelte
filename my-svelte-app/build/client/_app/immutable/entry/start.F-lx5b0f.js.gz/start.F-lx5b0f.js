import{a as t}from"../chunks/entry.B2Ph2g75.js";export{t as start};
